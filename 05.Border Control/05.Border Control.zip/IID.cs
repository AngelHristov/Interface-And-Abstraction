﻿namespace _05.Border_Control
{
    public interface IID
    {
        string ID { get; }
    }
}
