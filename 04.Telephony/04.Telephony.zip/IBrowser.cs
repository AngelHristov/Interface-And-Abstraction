﻿namespace _04.Telephony
{
    public interface IBrowser
    {
        string BrowseWWW(string url);
    }
}
