﻿namespace _04.Telephony
{
    interface ICaller
    {
        string CallOtherPhones(string number);

    }
}
