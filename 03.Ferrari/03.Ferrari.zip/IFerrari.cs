﻿namespace _03.Ferrari
{
    public interface IFerrari
    {
        string UseBrakes();

        string PushTheGasPedal();
    }
}
